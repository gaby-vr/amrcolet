<?php if(!defined('ABSPATH')) exit;



add_action('woocommerce_thankyou', 'amr_send_order_to_platform', 10, 1);

function amr_send_order_to_platform( $order_id )
{
    if ( ! $order_id ) {
        return;
    }

    // Allow code execution only once 
    if( ! get_post_meta( $order_id, '_thankyou_action_done', true ) ) {

        $data = array();
        $data['receiver'] = array();
        $data['sender'] = array();
        $data['packages'] = array();

        $setari = get_option('amr_settings');

        $order = wc_get_order( $order_id );



        $date_comanda = $order->get_data();


        // TODO: de vazut cu observatii comada
        // $data['observatii'] = $order->get_customer_note();

        $data['packages']['nr_colete'] = 0;

        foreach ( $order->get_items() as $item_id => $item ) {

            $product = $item->get_product();

            $data['packages']['width'][] = $product->get_width();
            $data['packages']['height'][] = $product->get_height();
            $data['packages']['length'][] = $product->get_length();
            $data['packages']['weight'][] = $product->get_weight();
            $data['packages']['nr_colete']++;
        }

        $data['packages']['type'] = $setari['type'];
        $data['packages']['content'] = $setari['content'];
        $data['packages']['awb'] = $setari['awb'];
        $data['packages']['pickup_day'] = $setari['pickup_day'];
        $data['packages']['start_pickup_hour'] = $setari['start_pickup_hour'];
        $data['packages']['end_pickup_hour'] = $setari['end_pickup_hour'];
        $data['packages']['work_saturday'] = $setari['work_saturday'];
        $data['packages']['open_when_received'] = $setari['open_when_received'];
        $data['packages']['retur_document'] = $setari['retur_document'];
        $data['packages']['ramburs'] = $setari['ramburs'];
        if($setari['ramburs'] > 1 && $order->get_payment_method() == 'cod') {
            $data['packages']['ramburs_value'] = $order->get_total();
            if($setari['ramburs'] > 2) {
                $data['packages']['iban'] = $setari['iban'];
                $data['packages']['titular_cont'] = $setari['titular_cont'];
            }
        } else {
            $data['packages']['ramburs'] = 1;
        }
        $data['packages']['titular_cont'] = $setari['titular_cont'];
        $data['packages']['iban'] = $setari['iban'];
        $data['packages']['api_key'] = $setari['api_key'];
        $data['packages']['customer_reference'] = $setari['customer_reference'];
        $data['packages']['assurance'] = '0'; // $order->get_total()
        $data['packages']['nr_colete'] = $setari['type'] == '1' ? $data['packages']['nr_colete'] : 0;


        // RECEIVER
        $data['receiver']['country'] = WC()->countries->countries[$date_comanda['shipping']['country']];
        $data['receiver']['country_code'] = $date_comanda['shipping']['country'];
        $data['receiver']['name'] = $date_comanda['shipping']['first_name'].' '.$date_comanda['shipping']['last_name'];
        $data['receiver']['phone'] = '' !== trim($date_comanda['shipping']['phone']) ? $date_comanda['shipping']['phone'] : $date_comanda['billing']['phone'];
        $data['receiver']['company'] = $date_comanda['shipping']['company'];
        $data['receiver']['email'] = $date_comanda['billing']['email'];
        $data['receiver']['postcode'] = $date_comanda['shipping']['postcode'];
        $data['receiver']['county'] = WC()->countries->get_states($date_comanda['shipping']['country'])[$date_comanda['shipping']['state']];
        $data['receiver']['locality'] = $date_comanda['shipping']['city'];
        // TODO: de vazut cum am stabilit sa fie cu adresa exacta
        $data['receiver']['address_1'] = $date_comanda['shipping']['address_1'];
        $data['receiver']['address_2'] = $date_comanda['shipping']['address_2'];


        // SENDER
        // The country/state
        $store_raw_country = get_option( 'woocommerce_default_country' );
        // Split the country/state
        $split_country = explode( ":", $store_raw_country );
        // Country and state separated:
        $store_country = $split_country[0];
        $store_state   = $split_country[1];

        $data['sender']['country'] = WC()->countries->countries[$store_country];
        $data['sender']['country_code'] = $store_country;
        $data['sender']['name'] = $setari['sender_name']; // TODO: de facut setare
        $data['sender']['phone'] = $setari['sender_phone']; // TODO: de facut setare
        $data['sender']['company'] = $setari['sender_company']; // TODO: de facut setare
        $data['sender']['email'] = $setari['sender_email']; // TODO: de facut setare
        $data['sender']['postcode'] = get_option( 'woocommerce_store_postcode');
        $data['sender']['county'] = WC()->countries->get_states($store_country)[$store_state];
        $data['sender']['locality'] = get_option('woocommerce_store_city');

        // TODO: de vazut cum am stabilit sa fie cu adresa exacta
        $data['sender']['address_1'] = get_option('woocommerce_store_address');
        $data['sender']['address_2'] = get_option('woocommerce_store_address_2');

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://amrcolet.ro/api/wordpress",
            CURLOPT_AUTOREFERER => true,
            CURLOPT_FRESH_CONNECT => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 3000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_NONE,
            //CURLOPT_POST => true,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array("Accept: application/json", 'Origin: '.$_SERVER['SERVER_NAME'], "Content-Type: application/json", "Key:".$setari['api_key'], "Connection: keep-alive"),
        ));

        $response = json_decode(curl_exec($curl), true);

        // error = textul erorii - posibilitati: apikey, domeniu, credite (rol 1), cont expirat (rol 2), curier negasit
        if(isset($response['message'])) {    
            $order->add_order_note($response['message']);
        } else {
            if($response['status'] === 422) {
                $order->add_order_note($response['error']);
            }
        }

        $err = curl_error($curl);

        if($err) {
            error_log(print_r($err,true));
        }
        curl_close($curl);

        // Flag the action as done (to avoid repetitions on reload for example)
        $order->update_meta_data( '_thankyou_action_done', true );
        $order->save();
    }
}