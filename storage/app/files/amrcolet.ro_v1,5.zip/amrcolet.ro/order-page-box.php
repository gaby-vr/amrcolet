<?php if(!defined('ABSPATH')) exit;

if(isset($setari['waiting_approval']) && $setari['waiting_approval'] == 1) {
    add_action( 'add_meta_boxes', 'amrcolet_order_meta_boxes' );
}

function amrcolet_order_meta_boxes()
{
    add_meta_box(
        'woocommerce-order-amrcolet',   // woocommerce-order-YOUR-UNIQUE-REF
        __(SITE_NAME.' - Trimite comanda'),
        'order_meta_box_amrcolet',
        'shop_order',
        'side',
        'default'
    );
}
function order_meta_box_amrcolet()
{
    $setari = get_option('amr_settings');
    if($errors = get_transient('amrcolet_errors')) {
        $errors = is_array($errors) ? $errors : [$errors];
        foreach ($errors as $key => $value) {
            echo '<div class="error notice is-dismissible">
                <p>'.$value.'</p>
            </div>';
        }
        delete_transient('amrcolet_errors');
    }

    $form = '<select form="amr_form_id" name="amr_address_id" id="amr_addresses" style="width: 100%; margin-top: 6px;" required>';
    if(isset($setari['addresses']) && is_array($setari['addresses'])) {
        foreach ($setari['addresses'] as $address) {
            $form .= '<option value="'.$address['id'].'">'.$address['address_name'].'</option>';
        }
    } else {
        $form .= '<option value="">'.__('Nu ai o adresa salvata in '.SITE_NAME).'</option>';
    }
    $form .= '</select>';
    $form .= '<button type="submit" form="amr_form_id" class="button button-primary right" style="margin-top: 12px;">'.__('Trimite').'</button>';
    $form .= '<div class="clear"></div>';

    echo $form;
}

//add form html outside post form
add_filter('admin_footer','amrcolet_order_form');

function amrcolet_order_form() {
    $form = '<form id="amr_form_id" action="'.admin_url( 'admin-post.php' ).'" method="post">';
    $form .= wp_nonce_field('amr_form_address');
    $form .= '<input type="hidden" name="action" value="amr_send_order">';
    $form .= '<input type="hidden" name="order_id" value="'.get_the_ID().'">';
    $form .= '</form>';

    echo $form;
}