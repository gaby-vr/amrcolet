<?php if(!defined('ABSPATH')) exit;
// pagina cu formularul pentru setari
/**
 * asteapta aprobare (bifa 0/1), = waiting_approval
 * continut (string:50), = content
 * tiparire awb (bifa/radio da/nu 1/2), = awb
 * program ridicare(select:In 1 zi/in 2 zile/in 3 zile), = pickup_day
 * orar ridicare (select1: 08 - 15, select2: 09 - 18), = start_pickup_hour, end_pickup_hour
 * optiuni curier (bife 0/1):
 * * livrare sambata = work_saturday
 * * deschidere colet la lirare = open_when_received
 * * retur documente = retur_document
 * ramburs (select:Fara ramburs/Ramburs cash/Ramburs in cont: 1/2/3), = ramburs
 * referinta client (string:50), = customer_reference (optional)
 * adaugare api (string:20) = api_key
 * tip pachet: (select:colet/plic 1/2) = type
 */
function amr_settings() {
	global $wpdb;
	/** Load WordPress Administration Bootstrap */
	require_once ABSPATH . 'wp-admin/admin.php';
	/** WordPress Translation Installation API */
	require_once ABSPATH . 'wp-admin/includes/translation-install.php';
	/** All the possible settings for this plugin */
	$plugin_attributes = [
		'waiting_approval',
		'content',
		'awb',
		'pickup_day',
		'start_pickup_hour',
		'end_pickup_hour',
		'work_saturday',
		'open_when_received',
		'retur_document',
		'ramburs',
		'titular_cont',
		'iban',
		'api_key',
		'customer_reference',
		'type',
		'addresses',
		'sender_name',
		'sender_company',
		'sender_phone',
		'sender_email',
	];
	if(isset($_POST) && !empty($_POST)) {
		check_admin_referer( 'amr-settings', '_wpnonce_amr-settings' );
		$error = '';
		if(
			!isset($_POST['content']) || '' === trim($_POST['content']) ||
			!isset($_POST['awb']) || '' === trim($_POST['awb']) ||
			!isset($_POST['pickup_day']) || '' === trim($_POST['pickup_day']) ||
			!isset($_POST['start_pickup_hour']) || '' === trim($_POST['start_pickup_hour']) ||
			!isset($_POST['end_pickup_hour']) || '' === trim($_POST['end_pickup_hour']) ||
			!isset($_POST['work_saturday']) || '' === trim($_POST['work_saturday']) ||
			!isset($_POST['open_when_received']) || '' === trim($_POST['open_when_received']) ||
			!isset($_POST['retur_document']) || '' === trim($_POST['retur_document']) ||
			!isset($_POST['ramburs']) || '' === trim($_POST['ramburs']) ||
			!isset($_POST['api_key']) || '' === trim($_POST['api_key']) ||
			!isset($_POST['type']) || '' === trim($_POST['type']) ||
			!isset($_POST['sender_name']) || '' === trim($_POST['sender_name']) ||
			!isset($_POST['sender_phone']) || '' === trim($_POST['sender_phone']) ||
			!isset($_POST['sender_email']) || '' === trim($_POST['sender_email'])
		) {
			$error = 'Campurile marcate cu <span class="required">*</span> sunt obligatorii';
		} else {
			// errror = textul erorii - posibilitati: apikey, domeniu, credite (rol 1), cont expirat (rol 2)
			$curl = curl_init();
	        curl_setopt_array($curl, array(
	            CURLOPT_URL => "https://amrcolet.ro/api/wordpress/check",
	            CURLOPT_AUTOREFERER => true,
	            CURLOPT_FRESH_CONNECT => true,
	            CURLOPT_RETURNTRANSFER => true,
	            CURLOPT_ENCODING => "",
	            CURLOPT_TIMEOUT => 3000,
	            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_NONE,
	            CURLOPT_POST => true,
	            CURLOPT_CUSTOMREQUEST => "POST",
	            CURLOPT_POSTFIELDS => json_encode($_POST),
	            // CURLOPT_HEADER => true, // includes the headers in the response
	            CURLOPT_HTTPHEADER => array("Accept: application/json", 'Origin: '.$_SERVER['SERVER_NAME'], "Content-Type: application/json", "Key:".$_POST['api_key'], "Connection: keep-alive"),
	        ));
	        $response = json_decode(curl_exec($curl), true);
	        $err = curl_error($curl);
	        $info = curl_getinfo($curl);
	        curl_close($curl);
	        if($response['status'] == 200) {
				$data = array(
					'waiting_approval' => $_POST['waiting_approval'] ?? null,
					'content' => $_POST['content'],
					'awb' => $_POST['awb'],
					'pickup_day' => $_POST['pickup_day'],
					'start_pickup_hour' => $_POST['start_pickup_hour'],
					'end_pickup_hour' => $_POST['end_pickup_hour'],
					'work_saturday' => $_POST['work_saturday'],
					'open_when_received' => $_POST['open_when_received'],
					'retur_document' => $_POST['retur_document'],
					'ramburs' => $_POST['ramburs'],
					'titular_cont' => $_POST['titular_cont'],
					'iban' => $_POST['iban'],
					'api_key' => $_POST['api_key'],
					'customer_reference' => $_POST['customer_reference'],
					'type' => $_POST['type'],
					'addresses' => $response['addresses'] ?? null,
					'sender_name' => $_POST['sender_name'],
					'sender_company' => $_POST['sender_company'],
					'sender_phone' => $_POST['sender_phone'],
					'sender_email' => $_POST['sender_email'],
				);
				update_option('amr_settings', $data);
				$message = $response['message'];
			} else {
				$error = $response['error'];
			}
		}
	} 
	$setari = get_option( 'amr_settings' );
	foreach ($plugin_attributes as $key) {
		$setari[$key] = isset($_POST[$key]) 
			? $_POST[$key] 
			: (isset($setari[$key]) ? $setari[$key] : '');
	}
?>
	<?php if(isset($error) && '' !== trim($error)): ?>
		<div class="error notice is-dismissible">
		    <p><?= $error ?></p>
		</div>
	<?php endif; ?>
	<?php if(isset($message) && '' !== trim($message)): ?>
		<div class="updated notice is-dismissible">
		    <p><?= $message ?></p>
		</div>
	<?php endif; ?>
	<div class="wrap">
		<h1><?= esc_html( get_admin_page_title() ) ?></h1>
		<p><?php printf(
			/* translators: %s: Asterisk symbol (*). */
			__( 'Required fields are marked %s' ),
			'<span class="required">*</span>'
		); ?></p>
		<form method="post" action="" novalidate="novalidate">
			<hr>
			<h2><?= __( 'Setari plugin') ?></h2>
			<table class="form-table" role="presentation">
				<tr class="form-field form-required">
					<th scope="row"><label for="sender_name"><?php _e( 'Verifica comanda' ); ?></label></th>
					<td>
						<label>
							<input name="waiting_approval" type="checkbox" class="regular-text" id="waiting_approval" style="max-width: 25em;" value="1" <?= $setari['waiting_approval'] == 1 ? 'checked' : '' ?>><?php _e('Da'); ?>
							<p class="description"><?php _e('Daca acest camp este bifat:' ); ?></p>
							<ul style="list-style: inherit;margin: 4px 1.25rem;color: #646970;">
								<li><?php _e('cererea de livrare nu se va trimite automat catre <a href="'.SITE_URL.'" target="_blank">'.SITE_NAME.'</a> dupa ce plata unei comenzi a fost efectuata;' ); ?></li>
								<li><?php _e('un formular cu adresele salvate in <a href="'.SITE_URL.'" target="_blank">'.SITE_NAME.'</a> va aparea in pagina unei comenzi si vei putea selecta de la care dintre acestea sa se faca expedierea;' ); ?></li>
							</ul>
						</label>
					</td>
				</tr>
			</table>
			<hr>
			<h2>Informatii generale</h2>
			<?php wp_nonce_field( 'amr-settings', '_wpnonce_amr-settings' ); ?>
			<table class="form-table" role="presentation">
				<tr class="form-field form-required">
					<th scope="row"><label for="content"><?php _e( 'Continut pachet' ); ?> <span class="required">*</span></label></th>
					<td>
						<input name="content" type="text" class="regular-text" id="content" required maxlength="50" style="max-width: 25em;" value="<?= $setari['content'] ?>">
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="awb"><?php _e( 'Tiparire AWB' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="awb" id="awb" required>
							<option value="1" <?= $setari['awb'] == 1 ? 'selected' : '' ?>>Da</option>
							<option value="2" <?= $setari['awb'] == 2 ? 'selected' : '' ?>>Nu</option>
						</select>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="pickup_day"><?php _e( 'Program ridicare' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="pickup_day" class="regular-text" id="pickup_day" required>
							<option value="0" <?= $setari['pickup_day'] === 0 || $setari['pickup_day'] === '0' ? 'selected' : '' ?>>Astazi (inainte de ora 15:00)</option>
							<option value="1" <?= $setari['pickup_day'] == 1 ? 'selected' : '' ?>>1 zi dupa comanda</option>
							<option value="2" <?= $setari['pickup_day'] == 2 ? 'selected' : '' ?>>2 zile dupa comanda</option>
						</select>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="start_pickup_hour"><?php _e( 'Orar ridicare' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="start_pickup_hour" id="start_pickup_hour" required>
							<?php for ($i = 8; $i <= 15 ; $i++): ?>
								<option value="<?= $i ?>" <?= $setari['start_pickup_hour'] == $i ? 'selected' : '' ?>><?= sprintf('%02d', $i) ?>:00</option>
							<?php endfor ?>
						</select>
						-
						<select name="end_pickup_hour" id="end_pickup_hour" required>
							<?php for ($i = 8; $i <= 18 ; $i++): ?>
								<option value="<?= $i ?>" <?= $setari['end_pickup_hour'] == $i ? 'selected' : '' ?>><?= sprintf('%02d', $i) ?>:00</option>
							<?php endfor ?>
						</select>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="work_saturday"><?php _e( 'Livrare sambata' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="work_saturday" id="work_saturday" required>
							<option value="0" <?= $setari['work_saturday'] == 0 ? 'selected' : '' ?>>Nu</option>
							<option value="1" <?= $setari['work_saturday'] == 1 ? 'selected' : '' ?>>Da</option>
						</select>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="open_when_received"><?php _e( 'Deschidere colet la livrare' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="open_when_received" id="open_when_received" required>
							<option value="0" <?= $setari['open_when_received'] == 0 ? 'selected' : '' ?>>Nu</option>
							<option value="1" <?= $setari['open_when_received'] == 1 ? 'selected' : '' ?>>Da</option>
						</select>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="retur_document"><?php _e( 'Retur documente' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="retur_document" id="retur_document" required>
							<option value="0" <?= $setari['retur_document'] == 0 ? 'selected' : '' ?>>Nu</option>
							<option value="1" <?= $setari['retur_document'] == 1 ? 'selected' : '' ?>>Da</option>
						</select>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="ramburs"><?php _e( 'Ramburs' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="ramburs" class="regular-text" id="ramburs" required>
							<option value="1" <?= $setari['ramburs'] == 1 ? 'selected' : '' ?>>Fara ramburs</option>
							<option value="2" <?= $setari['ramburs'] == 2 ? 'selected' : '' ?>>Ramburs cash</option>
							<option value="3" <?= $setari['ramburs'] == 3 ? 'selected' : '' ?>>Ramburs in cont</option>
						</select>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="titular_cont"><?php _e( 'Titular cont' ); ?></label></th>
					<td>
						<input name="titular_cont" type="text" class="regular-text wp-suggest-user" id="titular_cont" required maxlength="50" style="max-width: 25em;" value="<?= $setari['titular_cont'] ?>">
						<p class="description"><?php _e( 'Titularul contului folosit pentru rambursul in cont bancar.' ); ?></p>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="iban"><?php _e( 'IBAN' ); ?></label></th>
					<td>
						<input name="iban" type="text" class="regular-text wp-suggest-user" id="iban" required maxlength="50" style="max-width: 25em;" value="<?= $setari['iban'] ?>">
						<p class="description"><?php _e( 'IBAN-ul folosit pentru rambursul in cont bancar.' ); ?></p>
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="customer_reference"><?php _e( 'Referinta client' ); ?></label></th>
					<td>
						<input name="customer_reference" type="text" class="regular-text wp-suggest-user" id="customer_reference" required maxlength="50" style="max-width: 25em;" value="<?= $setari['customer_reference'] ?>">
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="api_key"><?php _e( 'Cheie API' ); ?> <span class="required">*</span></label></th>
					<td><input name="api_key" type="password" class="regular-text" id="api_key" required style="max-width: 25em;" value="<?= $setari['api_key'] ?>"></td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="type"><?php _e( 'Tip pachet' ); ?> <span class="required">*</span></label></th>
					<td>
						<select name="type" class="regular-text" id="type" required>
							<option value="1" <?= $setari['type'] == 1 ? 'selected' : '' ?>>Colet</option>
							<option value="2" <?= $setari['type'] == 2 ? 'selected' : '' ?>>Plic</option>
						</select>
					</td>
				</tr>
			</table>
			<hr>
			<h2>Persoana de contact</h2>
			<table class="form-table" role="presentation">
				<tr class="form-field form-required">
					<th scope="row"><label for="sender_name"><?php _e( 'Nume' ); ?> <span class="required">*</span></label></th>
					<td>
						<input name="sender_name" type="text" class="regular-text" id="sender_name" required maxlength="50" style="max-width: 25em;" value="<?= $setari['sender_name'] ?>">
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="sender_company"><?php _e( 'Nume companie' ); ?></label></th>
					<td>
						<input name="sender_company" type="text" class="regular-text" id="sender_company" required maxlength="50" style="max-width: 25em;" value="<?= $setari['sender_company'] ?>">
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="sender_phone"><?php _e( 'Telefon' ); ?> <span class="required">*</span></label></th>
					<td>
						<input name="sender_phone" type="tel" class="regular-text" id="sender_phone" required maxlength="50" style="max-width: 25em;" value="<?= $setari['sender_phone'] ?>">
					</td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="sender_email"><?php _e( 'Email' ); ?> <span class="required">*</span></label></th>
					<td>
						<input name="sender_email" type="email" class="regular-text" id="sender_email" required maxlength="50" style="max-width: 25em;" value="<?= $setari['sender_email'] ?>">
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save' ), 'primary', 'save' ); ?>
		</form>
	</div> <?php
}
// adaugam pagina in admin menu
function amr_add_toplevel_menu() {
	add_menu_page(
		__('Settings').' '.SITE_NAME, // page_title
		SITE_NAME, // menu_title
		'manage_options', // capability
		'amr', // menu_slug
		'amr_settings', // function
		'dashicons-clipboard', // icon_url
		null // position
	);
}
add_action( 'admin_menu', 'amr_add_toplevel_menu' );
// add settings for other files
$setari = get_option('amr_settings');