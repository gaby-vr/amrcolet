<?php
/*
Plugin Name: AMR Colet
Description: Trimite colete prin comandă online rapid și ieftin oriunde în România.
Author:      amrcolet.ro
Author URI:  https://amrcolet.ro/
Version:     1.8
Text Domain: amr
*/

if(!defined('ABSPATH')) exit;


/*
// TODO: la dezinstalare se sterg informatiile
function amr_on_uninstall() {

	if ( ! current_user_can( 'activate_plugins' ) ) return;
	
}
register_uninstall_hook( __FILE__, 'amr_on_uninstall' );*/

CONST SITE_NAME = 'AMR Colet';
CONST SITE_URL = 'https://amrcolet.ro/';

require_once plugin_dir_path(__FILE__).'settings-page.php';
require_once plugin_dir_path(__FILE__).'request.php';
require_once plugin_dir_path(__FILE__).'order-page-box.php';